@echo off
setlocal DisableDelayedExpansion
if not "%~2"=="" goto muitos
set "LEGAIA_ARQUIVO=%~1"
if not exist "%~dp0dados\aplicador.ps1" goto incompleto
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0dados\aplicador.ps1" -Modo Verificar
set "LEGAIA_RESULTADO=%ERRORLEVEL%"
echo.
pause
exit /b %LEGAIA_RESULTADO%
:muitos
echo Arraste apenas UM arquivo BIN por vez.
pause
exit /b 2
:incompleto
echo Pacote incompleto. Extraia o ZIP inteiro, incluindo a pasta dados.
pause
exit /b 4
