﻿#requires -version 5.1
[CmdletBinding()]
param(
    [ValidateSet('Aplicar', 'Verificar')][string]$Modo = 'Aplicar',
    [string]$Arquivo = $env:LEGAIA_ARQUIVO,
    [string]$PastaDestino,
    [switch]$SemInterface
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$sourceGuard = $null
$workDirectory = $null
$oldXdeltaOptions = $env:XDELTA

function Get-Sha256([string]$Path) {
    $stream = [IO.File]::OpenRead($Path)
    $algorithm = [Security.Cryptography.SHA256]::Create()
    try {
        return [BitConverter]::ToString($algorithm.ComputeHash($stream)).Replace('-', '').ToLowerInvariant()
    } finally {
        $algorithm.Dispose()
        $stream.Dispose()
    }
}

function Invoke-PatchTool {
    $manifestPath = Join-Path $PSScriptRoot 'manifesto.json'
    $manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
    Write-Host ''
    Write-Host ('Legend of Legaia PT-BR - versao ' + $manifest.version) -ForegroundColor Cyan
    Write-Host ('Modo: ' + $Modo)
    Write-Host ''

    if ([string]::IsNullOrWhiteSpace($Arquivo)) {
        if ($SemInterface) { throw 'Informe um arquivo BIN.' }
        Add-Type -AssemblyName System.Windows.Forms
        $dialog = New-Object System.Windows.Forms.OpenFileDialog
        try {
            $dialog.Title = 'Selecione o BIN original de Legend of Legaia'
            $dialog.Filter = 'Imagem do jogo (*.bin)|*.bin|Todos os arquivos (*.*)|*.*'
            $dialog.Multiselect = $false
            if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {
                Write-Host 'Operacao cancelada. Nenhum arquivo foi alterado.'
                return 5
            }
            $Arquivo = $dialog.FileName
        } finally { $dialog.Dispose() }
    }

    if (-not (Test-Path -LiteralPath $Arquivo -PathType Leaf)) {
        throw 'O arquivo selecionado nao foi encontrado. Extraia o jogo e selecione seu BIN.'
    }
    $source = Get-Item -LiteralPath $Arquivo
    if ($source.Extension -ine '.bin') {
        Write-Host 'Selecione o BIN original. Nao selecione CUE, ISO, CHD, ZIP ou o patch.' -ForegroundColor Yellow
        Write-Host 'Mudar a extensao nao converte o formato. Veja COMO INSTALAR.txt.'
        return 2
    }

    # Mantem a origem aberta somente para leitura durante a verificacao e a aplicacao.
    $script:sourceGuard = [IO.File]::Open($source.FullName, [IO.FileMode]::Open,
        [IO.FileAccess]::Read, [IO.FileShare]::Read)
    if ($sourceGuard.Length -ne [long]$manifest.source.bytes) {
        Write-Host 'BIN INCOMPATIVEL: tamanho diferente do original exigido.' -ForegroundColor Yellow
        Write-Host ('Esperado: ' + $manifest.source.bytes + ' bytes; encontrado: ' + $sourceGuard.Length)
        return 2
    }
    Write-Host 'Conferindo o arquivo completo. Aguarde...'
    $sourceHash = Get-Sha256 $source.FullName
    Write-Host ('SHA-256: ' + $sourceHash)
    if ($sourceHash -eq $manifest.target.sha256) {
        Write-Host ('Este BIN JA ESTA TRADUZIDO na versao ' + $manifest.version + '.') -ForegroundColor Green
        Write-Host 'Ele corresponde exatamente ao resultado esperado. Nao reaplique o patch.'
        if ($Modo -eq 'Verificar') { return 0 }
        return 3
    }
    if ($sourceHash -ne $manifest.source.sha256) {
        Write-Host 'BIN INCOMPATIVEL com este patch.' -ForegroundColor Yellow
        Write-Host 'Pode ser outra edicao, outra extracao ou uma imagem ja modificada.'
        Write-Host ('SHA-256 original exigido: ' + $manifest.source.sha256)
        Write-Host 'Nenhuma alteracao foi feita. Use o original compativel, sem outros patches.'
        return 2
    }
    Write-Host 'BIN ORIGINAL COMPATIVEL.' -ForegroundColor Green
    if ($Modo -eq 'Verificar') {
        Write-Host 'A verificacao terminou. Nenhum arquivo foi alterado.'
        return 0
    }

    if (-not [Environment]::Is64BitOperatingSystem) {
        throw 'O aplicador incluido requer Windows de 64 bits.'
    }
    $engine = Join-Path $PSScriptRoot 'xdelta3.exe'
    $patch = Join-Path $PSScriptRoot $manifest.patch.file
    foreach ($requiredFile in @($engine, $patch)) {
        if (-not (Test-Path -LiteralPath $requiredFile -PathType Leaf)) {
            throw 'O pacote esta incompleto. Extraia novamente o ZIP inteiro, incluindo a pasta dados.'
        }
    }
    if ((Get-Sha256 $engine) -ne $manifest.engine.sha256 -or
        (Get-Sha256 $patch) -ne $manifest.patch.sha256) {
        throw 'A integridade do aplicador ou do patch nao confere. Extraia novamente o pacote original.'
    }

    if ([string]::IsNullOrWhiteSpace($PastaDestino)) {
        $PastaDestino = Join-Path $source.DirectoryName 'Legend of Legaia PT-BR'
    }
    $destination = [IO.Path]::GetFullPath($PastaDestino)
    if (Test-Path -LiteralPath $destination) {
        Write-Host 'A pasta de destino ja existe. Nada sera substituido:' -ForegroundColor Yellow
        Write-Host $destination
        Write-Host 'Guarde ou renomeie essa pasta antes de aplicar novamente.'
        return 6
    }
    $parent = [IO.Path]::GetDirectoryName($destination)
    if (-not (Test-Path -LiteralPath $parent -PathType Container)) {
        throw 'A pasta que recebera o jogo nao existe.'
    }
    $driveRoot = [IO.Path]::GetPathRoot($destination)
    if ($driveRoot -match '^[A-Za-z]:\\$') {
        $drive = New-Object IO.DriveInfo($driveRoot)
        if ($drive.AvailableFreeSpace -lt ([long]$manifest.target.bytes + 16MB)) {
            throw 'Espaco insuficiente. Libere ao menos 500 MB na unidade de destino.'
        }
    }

    $script:workDirectory = Join-Path $parent ('.legaia-em-preparo-' + [guid]::NewGuid().ToString('N'))
    [IO.Directory]::CreateDirectory($workDirectory) | Out-Null
    # Nomes temporarios ASCII tambem funcionam em versões do xdelta sem suporte a Unicode.
    $temporaryBin = Join-Path $workDirectory 'traduzido.bin'
    Write-Host 'Aplicando a traducao em um NOVO arquivo. Aguarde...'
    $env:XDELTA = $null
    & $engine -d -D -R -s $source.FullName $patch $temporaryBin 2>&1 | ForEach-Object { Write-Host $_ }
    if ($LASTEXITCODE -ne 0) { throw ('O xdelta encerrou com erro ' + $LASTEXITCODE + '.') }
    Write-Host 'Conferindo a integridade do jogo traduzido...'
    if ((Get-Item -LiteralPath $temporaryBin).Length -ne [long]$manifest.target.bytes -or
        (Get-Sha256 $temporaryBin) -ne $manifest.target.sha256) {
        throw 'O resultado nao corresponde ao jogo traduzido esperado. A copia incompleta sera descartada.'
    }

    $outputBin = Join-Path $workDirectory $manifest.target.file
    [IO.File]::Move($temporaryBin, $outputBin)
    $cueName = [IO.Path]::ChangeExtension($manifest.target.file, '.cue')
    $cue = 'FILE "' + $manifest.target.file + '" BINARY' + "`r`n  TRACK 01 MODE2/2352`r`n    INDEX 01 00:00:00`r`n"
    [IO.File]::WriteAllText((Join-Path $workDirectory $cueName), $cue, [Text.Encoding]::ASCII)
    $receipt = @(
        'Legend of Legaia - Traducao PT-BR',
        ('Versao do patch: ' + $manifest.version),
        ('Data do pacote: ' + $manifest.date),
        ('Aplicado em: ' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')),
        ('BIN original SHA-256: ' + $manifest.source.sha256),
        ('BIN traduzido SHA-256: ' + $manifest.target.sha256),
        'Integridade do resultado: CONFIRMADA',
        ('Abra o arquivo: ' + $cueName),
        'Para relatar erros, informe a versao do patch acima.'
    ) -join "`r`n"
    [IO.File]::WriteAllText((Join-Path $workDirectory 'VERSAO DA TRADUCAO.txt'), $receipt + "`r`n", [Text.Encoding]::UTF8)
    # Confirma os caminhos antes de mover a pasta criada por esta execucao.
    if ([IO.Path]::GetDirectoryName([IO.Path]::GetFullPath($workDirectory)) -ne $parent -or
        [IO.Path]::GetDirectoryName($destination) -ne $parent) {
        throw 'Destino fora da pasta selecionada.'
    }
    # Publica o conjunto completo somente apos validar; recusa destino existente.
    [IO.Directory]::Move($workDirectory, $destination)
    $script:workDirectory = $null
    Write-Host ''
    Write-Host 'TRADUCAO APLICADA E VERIFICADA!' -ForegroundColor Green
    Write-Host 'Seu BIN original foi preservado. Abra este CUE no emulador:'
    Write-Host (Join-Path $destination $cueName)
    return 0
}

try {
    $result = Invoke-PatchTool
} catch {
    Write-Host ''
    Write-Host ('ERRO: ' + $_.Exception.Message) -ForegroundColor Red
    Write-Host 'O arquivo original nao foi alterado.'
    $result = 4
} finally {
    $env:XDELTA = $oldXdeltaOptions
    if ($null -ne $sourceGuard) { $sourceGuard.Dispose() }
    if ($null -ne $workDirectory -and [IO.Directory]::Exists($workDirectory)) {
        # Remove somente arquivos conhecidos do diretorio temporario exclusivo desta execucao.
        # Nao ha exclusao recursiva nem uso de curingas.
        foreach ($file in [IO.Directory]::GetFiles($workDirectory)) { [IO.File]::Delete($file) }
        [IO.Directory]::Delete($workDirectory, $false)
    }
}
exit $result
